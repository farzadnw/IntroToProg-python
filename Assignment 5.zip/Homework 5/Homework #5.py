# -------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  April 30, 2018
# ChangeLog: (Farzad Honarfar, 4/30/2018)
#   RRoot, 11/02/2016, Created starting template
#   <Farzad Honarfar, ???, Added code to complete assignment 5
# https://www.tutorialspoint.com/python/python_dictionary.htm
# -------------------------------------------------#

# -- Data --#
# declare variables and constants
dicrow = {"task":(),"proitiry":()}

# objFile = An object that represents a file5
objFile = open("todo.text","r")

# strData = A row of text data from the file
strData = objFile.readline()
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
dicRow = {"task": strData.split(",")[0]}, { strData.split(",")[1]}
dictable= dicRow
# lstTable = A dictionary that acts as a 'table' of rows
for line in objFile:
    strData = line
    dicRow = {"task":strData.split(",")[0]}, {"proitiry": strData.split(",")[1]}
    dictable += dicRow,


# strMenu = A menu of user options
print("menu of options")
while(True):

    menu = input("Press (1)show current data ,\n"
                  "press (2) to add a new item,\n"
                  "press (3) remove an existing item,\n"
                  "press (4) save data to file,\n"
                  "Press (5) Exit Program")
    # -- Processing --#
    # Step 1
    # When the program starts, load the any data you have
    # in a text file called ToDo.txt into a python Dictionary

    if menu == "1": print(dictable)
    # Step 2
    # Display a menu of choices to the user
    if menu == "2":
        strtask = input("enter a task")
        strPriority = input("enter Priority")

        objFile = open("todo.text", "a")
        objFile.write(str(dicnewrow))
        objFile.close()
    # Step 3
    # Display all todo items to user
    if menu == "3":
        if 'task' in (dicnewrow):
            del dicnewrow["task","proitiry"]
    # Step 4
    # Add a new item to the list/Table
    # Step 5
    # Remove a new item to the list/Table

    # Step 6
    # Save tasks to the ToDo.txt file
    if menu == "4":
        objFile = open("todo.text", "a")
        dicnewrow = {"task", "proitiry"}
        objFile.write(str(dicnewrow))
        objFile.close()
        # Step 7
        # Exit program
    if menu == "5": break

4




