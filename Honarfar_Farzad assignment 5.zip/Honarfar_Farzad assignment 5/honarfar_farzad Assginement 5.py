# ------------------------------------------------------------------------------------------ #
# Title: Assignment05
# Desc: This assignment demonstrates using dictionaries, files, and exception handling
# Change Log: (Who, When, What)
#   RRoot,1/1/2030,Created Script
#   Farzad Honarfar,2/27/2026,Converted to JSON, dictionaries, and error handling
# ------------------------------------------------------------------------------------------ #

# TODO: Import the json
import json

# Define the Data Constants
MENU: str = '''
---- Course Registration Program ----
  Select from the following menu:  
    1. Register a Student for a Course
    2. Show current data  
    3. Save data to a file
    4. Exit the program
----------------------------------------- 
'''

FILE_NAME: str = "Enrollments.json"


student_first_name: str = ''
student_last_name: str = ''
course_name: str = ''
menu_choice: str = ''
student_data: dict = {}
students: list = []
file = None

try:
    with open(FILE_NAME, "r") as file:
        students = json.load(file)
except FileNotFoundError:
    students = []
except json.JSONDecodeError:
    students = []
except Exception as e:
    print("Error loading file:", e)


while True:

    print(MENU)
    menu_choice = input("What would you like to do: ")

  
    if menu_choice == "1":

        try:
            student_first_name = input("Enter the student's first name: ").strip()
            if not student_first_name:
                raise ValueError("First name cannot be empty")

            student_last_name = input("Enter the student's last name: ").strip()
            if not student_last_name:
                raise ValueError("Last name cannot be empty")

            course_name = input("Please enter the name of the course: ").strip()

            student_data = {
                "FirstName": student_first_name,
                "LastName": student_last_name,
                "Course": course_name
            }

            students.append(student_data)

            print(f"You have registered {student_first_name} {student_last_name} for {course_name}.")

        except ValueError as e:
            print("Input Error:", e)

        continue

    
    elif menu_choice == "2":
        print("-" * 50)
        for student in students:
            print(f"{student['FirstName']}, {student['LastName']}, {student['Course']}")
        print("-" * 50)
        continue

   
    elif menu_choice == "3":
        try:
            with open(FILE_NAME, "w") as file:
                json.dump(students, file, indent=4)

            print("The following data was saved to file:")
            for student in students:
                print(f"{student['FirstName']} {student['LastName']} - {student['Course']}")

        except Exception as e:
            print("Error saving file:", e)

        continue

    elif menu_choice == "4":
        break

    else:
        print("Please only choose option 1, 2, 3, or 4")

print("Program Ended")